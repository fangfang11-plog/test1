#pragma once
void user_menu();
void Login_menu();
void Register_menu();
void menu_main();
void back_cipher();
