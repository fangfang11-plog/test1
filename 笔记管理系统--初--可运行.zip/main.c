#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"function.h"
#include"menu.h"
int main() {

	user_menu();

	system("pause");
	return 0;
}