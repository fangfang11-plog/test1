﻿#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"function.h"
#include"menu.h"



//切割指令
/*
	指令有<，但缺少>，报错
	忽视两个<>中间的字符，只取第一个<>前面的字符作为指令
*/
Status SplitCommand(char* str, char* order, char* title0, char* title1)
{
	int i, j = 0, k = 0, m = 0, flag0 = 0, flag1 = 0;
	int len = strlen(str);
	for (i = 0; i < len; i++)
	{
		if ((str[i] == '<' ||str[i]=='"')&& flag0 == 0)
		{	//第一个文件名
			for (j = 0, i++; str[i] != '>'&&str[i] != '"'; j++, i++)
			{
				if (str[i] == '\0')
				{
					printf("输入指令格式有误\n");
					return ERROR;
				}
				title0[j] = str[i];
				flag0 = 1;
			}
		}
		else if ((str[i] == '<'|| str[i] =='"')&& flag0 == 1)
		{	//若有第二个文件名
			for (k = 0, i++; str[i] != '>'&&str[i]!='"'; k++, i++)
			{
				if (str[i] == '\0')
				{
					printf("输入指令格式有误\n");
					return ERROR;
				}
				title1[k] = str[i];
			}
		}
		else
		{	//指令
			order[m] = str[i];
			m++;
		}
	}

	title0[j++] = '\0';
	title1[k++] = '\0';
	order[m++] = '\0';

	return TRUE;
}

Status IsCommand(char* title)
{
	int len = strlen(title);
	int i;
	for (i = 0; i < len; i++)
	{
		if (title[i] == '.')
			return TRUE;
	}
	return ERROR;
}




Status deldir(char* p)
{
	if (p[0] == 'r' && p[1] == 'm' && p[2] == '-' && p[3] == 'r' && p[4] == '<')
	{
		int i = 0;
		while (p[i] != '>' && p[i] != '\0')
		{
			i++;
		}//这时候跳出循环的p[i]要么是>或者是\0
		if (p[i] == '\0')
		{
			printf("指令输入错误，请重新输入！\n");
			return ERROR;
		}
		else//进入到这一步的话说明p[i]=='>'的
		{
			char cmd[255] = { 'r','m','d','i','r',' ','/','s',' ' };
			for (int n = 5, j = 9; n < i; n++, j++)
			{
				cmd[j] = p[n];
			}
			//printf("%s\n",cmd);
			system(cmd);
			printf("指令执行成功！\n");
			return TRUE;
		}

	}
	else
	{
		printf("指令输入错误，请重新输入!\n");
		return ERROR;
	}
}


Status sortfile(char* p)//½«Ä¿±êÎÄ¼þ¼Ð½øÐÐÅÅÐò
{
	char title0[15];
	char title1[15];
	char Userorder[25];
	char tureorder[100] = { 'd','i','r',' ','/','b',' ' };

	SplitCommand(p, Userorder, title0, title1);

	strcat(tureorder, title0);

	printf("%s\n", tureorder);
	system(tureorder);
	system("pause");
}


//改变路径（刘俊帆）
Status mvfile(char* p)//移动
{
	char title0[15];
	char title1[15];
	char Userorder[100];
	char tureorder[100] = { 'm','o','v','e',' ' };

	SplitCommand(p, Userorder, title0, title1);

	strcat(tureorder, title0);

	int L = strlen(tureorder);
	tureorder[L] = ' ';

	strcat(tureorder, title1);

	printf("%s\n", tureorder);
	system(tureorder);
	system("pause");
}


//检查小数点,检查到时返回TRUE
Status check_dot(char* str) {
	char* p = str;
	while (p) {
		
		if (*p == '.') {
			return TRUE;
		}
		else {
			p++;
		}
		if (*p == '\0') {
			return ERROR;
		}

	}
	return ERROR;

}




//优化部分：SearchByTag_Names现在直接把所有带标签内容的文件夹打印出来而不是返回一个指针/不允许添加重名标签
//待解决部分：不太遍历的原理不太清晰，递归的使用不知道对不对
//新增部分：目标文件夹标签的显示/目标文件夹标签的删除
Status AddFolderTag(FolderTreePtr F_T, char* folder_title, char* TagNode)//添加标签
{
	if (F_T == NULL) {
		return ERROR;
	}
	FolderPtr temp = Find_folder(F_T, folder_title);
	if (temp == NULL) {
		printf("未找到指定文件夹\n");
		return ERROR;
	}
	int i;
	for (i = 0; i < 5; i++) {
		if (strcmp(temp->folder_tag[i].tag_node, TagNode) == 0) {
			printf("标签重复");
			return ERROR;

		}
	}
	i = 0;
	while (i<5&&strlen(temp->folder_tag[i].tag_node) != 0) {
		i++;
	}
	if (i > 4) {
		printf("标签已满");
		return ERROR;
	}
	strcpy(temp->folder_tag[i].tag_node, TagNode);
	return TRUE;
	//for (i = 0; i < 5; i++) {
	//	while (strcmp(temp->folder_tag[i].tag_node, TagNode)) {//如果没有重名标签则进入循环
	//		if (strlen(temp->folder_tag[0].tag_node) == 0) {
	//			strcpy(temp->folder_tag[0].tag_node, TagNode);
	//			return TRUE;
	//		}
	//		if (strlen(temp->folder_tag[1].tag_node) == 0) {
	//			strcpy(temp->folder_tag[1].tag_node, TagNode);
	//			return TRUE;
	//		}
	//		if (strlen(temp->folder_tag[2].tag_node) == 0) {
	//			strcpy(temp->folder_tag[2].tag_node, TagNode);
	//			return TRUE;
	//		}
	//		if (strlen(temp->folder_tag[3].tag_node) == 0) {
	//			strcpy(temp->folder_tag[3].tag_node, TagNode);
	//			return TRUE;
	//		}
	//		if (strlen(temp->folder_tag[4].tag_node) == 0) {
	//			strcpy(temp->folder_tag[4].tag_node, TagNode);
	//			return TRUE;
	//		}
	//	}
	//}
	printf("已有重名标签，添加失败\n");
	return ERROR;
}

Status SearchByTag_Names(FolderTreePtr F_T, char* TagNode)//这是整棵树查找，对应指令：tag- s” 标签内容 ”
{
	LQueue* Q = NULL;
	Queue_Init(&Q);
	Queue_In(&Q, F_T->root);//如果是在当前目录下查找就是Queue_In(&Q, FolderPtr BNode);
//出队
	while (!Queue_Empty(Q)) {//如果跳出循环，说明没有找到该文件
		FolderPtr node = Queue_Front(Q);
		if (!node) {
			Queue_Out(&Q);
			continue;
		}
		int i;
		for (i = 0; i < 5; i++) {
			if (strcmp(node->folder_tag[i].tag_node, TagNode) == 0) {
				printf("文件夹名\t%s", node->folder_title);
				SearchByTag_Namesa(node, TagNode);//不太清晰遍历的原理，这里的递归可能需要讨论
				return TRUE;
			}
		}
		Queue_Out(&Q);
		if (node->left) {
			Queue_In(&Q, node->left);
		}
		if (node->right) {
			Queue_In(&Q, node->right);
		}
	}
	free(Q);
	Q = NULL;
	return ERROR;
}

Status SearchByTag_Namesa(FolderPtr F_T, char* TagNode)//这是在当前目录下查找，对应指令：tag -sa” 标签内容 ”
{
	LQueue* Q = NULL;
	Queue_Init(&Q);
	Queue_In(&Q, F_T);
	//出队
	while (!Queue_Empty(Q)) {//如果跳出循环，说明没有找到该文件
		FolderPtr node = Queue_Front(Q);
		if (!node) {
			Queue_Out(&Q);
			continue;
		}
		int i;
		for (i = 0; i < 5; i++) {
			if (strcmp(node->folder_tag[i].tag_node, TagNode) == 0) {
				printf("文件夹名\t%s", node->folder_title);
				SearchByTag_Namesa(node, TagNode);

			}
		}
		Queue_Out(&Q);
		if (node->left) {
			Queue_In(&Q, node->left);
		}
		if (node->right) {
			Queue_In(&Q, node->right);
		}
	}
	free(Q);
	Q = NULL;
	return ERROR;
}

Status PrintTag(FolderTreePtr F_T, char* folder_title)//打印目标文件夹的标签
{
	if (F_T == NULL) {
		return ERROR;
	}
	FolderPtr p = Find_folder(F_T, folder_title);
	if (p == NULL) {
		printf("不存在目标文件夹\n");
		return ERROR;
	}
	int i;
	printf("文件夹名\t%s\n", p->folder_title);
	for (i = 0; i < 5; i++) {
		printf("标签\t%s\n", p->folder_tag[i].tag_node);
	}
	return TRUE;
}

Status DeleTag(FolderTreePtr F_T, char* folder_title, char* TagNode)//删除目标文件夹的标签
{
	if (F_T == NULL) {
		return ERROR;
	}
	FolderPtr p = Find_folder(F_T, folder_title);
	if (p == NULL) {
		printf("不存在目标文件夹\n");
		return ERROR;
	}
	int i;
	for (i = 0; i < 5; i++) {//因为不存在标签重名，因此只需要遍历查找目标标签即可
		if (strcmp(p->folder_tag[i].tag_node, TagNode) == 0) {
			strcpy(p->folder_tag[i].tag_node, "\0");
			return TRUE;
		}
	}
	printf("输入错误！标签不存在！\n");//遍历完都没找到目标标签
	return ERROR;
}





Status ISgrep(char* p)
{
	if (p[0] != 'I' || p[1] != 's' || p[2] != '<')//检测IS<是否正确
	{
		return ERROR;
	}
	else
	{
		char s[100] = { 'c','d',' ' };

		int i = 3, j = 0;
		while (p[i] != '>' && p[i] != '\0')
		{
			s[3 + j] = p[i];//检测的同时把路劲写入s中
			i++; j++;
		}

		if (p[i] == '\0')//检测有没有>
		{
			return ERROR;
		}
		else
		{
			int temp = 0;
			char temps[15] = { '\0' };
			while (p[i + temp + 1] != '"' && p[i + temp + 1] != '\0')//检测>后面是不是grep并且有没有第一个"
			{
				temps[temp] = p[i + temp + 1];
				temp++;
			}

			int flag = 0;
			while (p[i + temp + 1 + flag + 1] != '"' && p[i + temp + flag + 2] != '\0')
			{
				flag++;
			}

			if (p[i + temp + 1] == '\0' || p[i + temp + flag + 2] == '\0' || strcmp(temps, "grep") != 0)
			{
				return ERROR;
			}
			else
			{
				s[3 + j] = ' ';
				strcat(s, "&& findstr /s /m ");
				int n = 0;
				while (p[i + n + 5] != '\0')
				{
					s[21 + j + n] = p[i + n + 5];
					n++;
				}
				s[21 + j + n] = ' '; s[21 + j + n + 1] = '.'; s[21 + j + n + 2] = 92; s[21 + j + n + 3] = '*'; s[21 + j + n + 4] = '\0';

				system(s);

				return TRUE;
			}
		}
	}
}

