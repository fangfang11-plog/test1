#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"function.h"
#include"menu.h"
int main() {
	U_file_r(user);
	user_menu();
	system("pause");
	return 0;
}